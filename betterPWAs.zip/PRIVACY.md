This extension does not collect or handle any user information beyond what
is necessary locally (i.e. never uploaded or shared) to support the described
functionality. The developer is not able to see any user data stored locally
and the source code can be inspected [here](https://github.com/benfredwells/betterPWAs).
